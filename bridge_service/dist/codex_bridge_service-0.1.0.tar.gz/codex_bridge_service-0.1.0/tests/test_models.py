from codex_bridge_service.models import (
    ArtifactRecord,
    AttachmentRecord,
    RunMode,
    ThreadRecord,
)


def test_thread_record_round_trips() -> None:
    record = ThreadRecord(
        thread_id="thr_123",
        title="First thread",
        workspace_id="ws_123",
        workspace_path="C:/CodexHA/workspaces/ws_123",
        status="idle",
        mode=RunMode.FULL_AUTO,
        attachments=[
            AttachmentRecord(
                attachment_id="att_1",
                filename="notes.txt",
                mime_type="text/plain",
                stored_path="C:/CodexHA/uploads/thr_123/notes.txt",
            )
        ],
        artifacts=[],
    )

    payload = record.model_dump()
    restored = ThreadRecord.model_validate(payload)

    assert restored.thread_id == "thr_123"
    assert restored.title == "First thread"
    assert restored.workspace_id == "ws_123"
    assert restored.workspace_path == "C:/CodexHA/workspaces/ws_123"
    assert restored.status == "idle"
    assert restored.mode is RunMode.FULL_AUTO
    assert len(restored.attachments) == 1
    assert restored.attachments[0].filename == "notes.txt"
    assert restored.attachments[0].attachment_id == "att_1"
    assert restored.artifacts == []


def test_thread_record_round_trips_nested_artifacts() -> None:
    record = ThreadRecord(
        thread_id="thr_456",
        title="Artifact thread",
        workspace_id="ws_456",
        workspace_path="C:/CodexHA/workspaces/ws_456",
        status="running",
        mode=RunMode.EDIT,
        attachments=[
            AttachmentRecord(
                attachment_id="att_2",
                filename="diagram.png",
                mime_type="image/png",
                stored_path="C:/CodexHA/uploads/thr_456/diagram.png",
            )
        ],
        artifacts=[
            ArtifactRecord(
                artifact_id="art_1",
                filename="report.md",
                mime_type="text/markdown",
                stored_path="C:/CodexHA/artifacts/thr_456/report.md",
            )
        ],
    )

    payload = record.model_dump()

    assert payload["mode"] == "edit"
    assert payload["attachments"][0]["stored_path"] == "C:/CodexHA/uploads/thr_456/diagram.png"
    assert payload["artifacts"][0]["artifact_id"] == "art_1"

    restored = ThreadRecord.model_validate(payload)

    assert restored.mode is RunMode.EDIT
    assert restored.attachments[0].mime_type == "image/png"
    assert restored.artifacts[0].artifact_id == "art_1"
    assert restored.artifacts[0].filename == "report.md"
    assert restored.artifacts[0].stored_path == "C:/CodexHA/artifacts/thr_456/report.md"
